//Exercise_3_Chandrasekaran

#include <msp430.h>
#include <templateEMP.h>


// Function declarations
void playMelody1();  // Function to play melody 1
void playMelody2();  // Function to play melody 2

void melodyPlayed(); // Function to play sequence of melodies

int knockMelody();   // Funtion to detect and return number of knocks
void playKnockMelody(); // Function to play melody based on the number of knocks


// Macros for Push-buttons
#define PB5 BIT3
#define PB6 BIT4

// Enable and disable parts of the code
//#define playJuke        //Definition for Task (a)
#define buttonKnock        //Definition for Task (b) ,(c) and (d)


// Melodies to be played
int melody1[7] = {2000, 3000, 4000, 5000, 6000, 7000, 8000};
int melody2[7] = {800, 700 , 850 , 750, 800, 700, 850};


// Variable to monitor state
unsigned int playPress = 0, pausePress = 0;


int main(void)
{
    initMSP();

    WDTCTL = WDTPW | WDTHOLD;   // stop watchdog timer

    P3DIR |= BIT6 ; // P3.6 output
    P3SEL |= BIT6 ; // P3.6 TA0 .2 option

    TA0CCTL2 = OUTMOD_3 ; // CCR2 set / reset
    TA0CCR0 = 1000; // PWM Period : 1000 us
    TA0CCR2 = 500; // CCR2 PWM duty cycle (50 %)
    TA0CTL = TASSEL_2 + MC_1 ; // SMCLK ; MC_1 -> up mode ;
    // MC_2 -> cont mode ,
    // MC_3 -> up - down - mode
    // In continous mode , internal reference
    // counts up to 0 xFFFF before starting at
    // 0 x0000 again . In any other mode it counts
    // up until it hits TACCR0
    // ( p . 364 in the family guide )

    #ifdef buttonKnock
        //Set P1.3 and P1.4 as input and pull it high (Ref Circuit Diagram)
        P1DIR &= ~(PB5+PB6);
        P1REN |= (PB5+PB6);
        P1OUT |= (PB5+PB6);

        //setting PB5 and PB6 interrupts
        __enable_interrupt(); //Enable Global interrupts
        P1IES |= (PB5 + PB6) ;  // set to 1 for High to low transition
        P1IFG &= ~(PB5 + PB6) ; //Clear the interrupt
        P1IE |= (PB5 + PB6); //Enable interrupt for PB5 and PB6
    #endif

    while(1){
        //Task (a)
        #ifdef playJuke

            playMelody1();
            __delay_cycles(1000000); //One second delay before melody 2 is played
            playMelody2();
            __delay_cycles(1000000); //One second delay before melody 1 is played again

        #endif
        //End of Task (a)

        //Task (b) main call
        #ifdef buttonKnock
            melodyPlayed();
        #endif
        //End of Task (b)

    }
}


void playMelody1(){
    unsigned int counter;

    #ifdef buttonKnock
        P1IE &= ~PB5; // disable interrupt while playing melody
    #endif

    for (counter = 0; counter < 7; counter ++) {

        if(pausePress == 1)
            break;

        TA0CCR0 =  melody1[counter] ;

        __delay_cycles(200000);

    }

    if(counter == 7)
        TA0CCR0 =  0;

    #ifdef buttonKnock
        P1IE |= PB5; //enable the interrupt again
    #endif
}

void playMelody2(){
    unsigned int counter;

    #ifdef buttonKnock
        P1IE &= ~PB5; // disable interrupt while playing melody
    #endif

    for (counter = 0; counter < 7; counter ++) {
        if(pausePress == 1) //if paused then break out of the loop and stop the melody
            break;
        TA0CCR0 =  melody2[counter] ;

        __delay_cycles(200000);


    }

    if(counter == 7)
        TA0CCR0 =  0;

    #ifdef buttonKnock
        P1IE |= PB5; // Enable interrupt again
    #endif
}


void melodyPlayed(){
    int knock = 0;

    // Disable PWM and change 3.6 to input
    P3DIR &= ~BIT6 ; // P3.6 input
    P3SEL &= ~BIT6 ; // PWM disabled

    if (P3IN & BIT6){
        // Board is Knocked once
        knock = 1;

        //Enable pull down resistor
        P3REN |= BIT6;
        P3OUT &= ~BIT6;

    }

    // Check if any button presses or knocks were recorded
    if(playPress > 0 || knock > 0){

        // Debounce time used to fully discharge the piezo (Referred from the thread:"Problems with Piezo")
        __delay_cycles(250000);

        // Disable pull down resistor
        P3REN &= ~BIT6;


        // One Second delay as soon as first press or a knock is detected
       // detected incase there is a second press
        __delay_cycles(1000000);


        // Check if 3.6 is still low
        if(P3IN & BIT6)
            knock = 2;


        // Enable PWM again and 3.6 is now output
        P3DIR |= BIT6 ;
        P3SEL |= BIT6 ;

        __delay_cycles(2500);

        //Interrupt triggered only once
        if(playPress == 1 || knock == 1)
            playMelody1();

        //Interrupt triggered twice
        else if(playPress == 2 || knock == 2)
            playMelody2();

        //Reset values for the next press/knock
        playPress = 0;
        pausePress = 0;
        knock = 0;

        //Enable pull down resistor
        P3REN |= BIT6;
        P3OUT &= ~BIT6; // pull down resistor

        __delay_cycles(2500);
    }


    // Pause the melody that is being played
    else if(pausePress == 1 || playPress == 0 || knock == 0){
        pausePress = 0;
        TA0CCR0 = 0;
    }

}


#ifdef  buttonKnock
// ISR for monitoring port1
# pragma vector = PORT1_VECTOR
__interrupt void Port_1 ( void ) {

    // P1IFG flag is set if the interrupt is generated
    // when PB5 is pressed i.e., BIT3 in P1IN changes from 1 -> 0
    if(P1IFG & PB5){
        if(P1IES ^ PB5)
            playPress++;

        __delay_cycles(250000);
        P1IFG &= ~PB5;
    }

    if(P1IFG & PB6){
        // when PB6 is pressed i.e., BIT4 in P1IN changes from 1 -> 0
        if(P1IES ^ PB6)
            pausePress = 1;

        __delay_cycles(250000);
        P1IFG &= ~PB6;
    }

}
#endif
