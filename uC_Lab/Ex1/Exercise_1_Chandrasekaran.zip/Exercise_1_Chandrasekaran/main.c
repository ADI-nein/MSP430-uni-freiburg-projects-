//Exercise_1_Chandrasekaran


#include <templateEMP.h>

//#define polling

//Macros for Push-buttons
#define PB5 BIT3
#define PB6 BIT4


//Macros for LEDs
#define D5 BIT6
#define D6 BIT5
#define D7 BIT0
#define D9 BIT7

//variables to monitor switch state
int swState5 = 0, swState6 = 0;

// Function to toggle D6 and D9 alternatively
void d6D9Toggle(){
    //Set P1.5 and P1.7 as output pins
    P1DIR |= (D6 + D9);

    //Toggling LED9 and LED6 as per the table
    P1OUT ^= D6;
    __delay_cycles(250000);

    P1OUT ^= D9;
    __delay_cycles(250000);

}


// Function to debouce buttons - Source MSP430 basics 7.3.3 Debouncing in Software
// Simplest method to debounce buttons
void debounceButtons(int button){
    // Read button state
    int prevButtonState = (P1IN & button);
    int nextButtonState = 0;

    // Compare the button states
    if (nextButtonState != prevButtonState) {
        // Debounce time of 5ms
        __delay_cycles(5000);

        // Read the button state after delay
        nextButtonState = (P1IN & button);

        // Button state unchanged after delay implies valid input
        if (nextButtonState != prevButtonState)
            prevButtonState = nextButtonState;
    }
}




// Main function
void main(void) {

    // Initialize controller
    initMSP();

    // Stop watchdog timer
    WDTCTL = WDTPW | WDTHOLD ;

    // Set P1.0, P1.5, P1.6 and P1.7 as output
    P1DIR |= (D5 + D6 + D7 + D9);

  //Set P1.3 and P1.4 as input and pull it high (Ref Circuit Diagram)
  P1DIR &= ~(PB5+PB6);
  P1REN |= (PB5+PB6);
  P1OUT |= (PB5+PB6);


  //setting PB5 interrupt
  P1IE |= PB5; //Enable interrupt for PB5
  __enable_interrupt(); //Enable Global interrupts
  P1IES |= PB5;  // set to 1 for High to low transition
  P1IFG &= ~PB5 ; //Clear the interrupt


// Infinite loop until supply is cut
while (1){

      #ifdef polling
      //initialising buttons
      int swTemp5, swTemp6 = P1IN;
      debounceButtons(PB5);
      debounceButtons(PB6);
      swTemp5 = (P1IN >> 3) & 0x01;
      swTemp6 = (P1IN >> 4) & 0x01;


      if(swTemp5 == 1)
              swState5 = 0;
          else
              swState5 = 1;

      if(swTemp6 == 1)
              swState6 = 0;
          else
              swState6 = 1;

      __delay_cycles(50);
      // Both switches are turned ON
      if(swState5 == 1 && swState6 == 1){
        // D9,D7 is ON and the others are turned OFF
        P1OUT |= D9;
        P1OUT &= ~(D5 + D6 + D7); // D7 works with Active Low
      }


      // PB5 is ON and PB6 is OFF
      else if(swState5 == 1 && swState6 !=1){
          //D6 and D9 toggle at 250ms alternatively, D7 and D5 are OFF
          d6D9Toggle();
          P1OUT &= ~D5;
          P1OUT |= D7;
      }



      // PB6 is ON and PB5 is OFF
      else if(swState5 !=1 && swState6 == 1){
          // D5 and D9 are turned ON and the others are turned OFF
          P1OUT |= (D5 + D9 + D7);
          P1OUT &= ~(D6);
      }


      // Both switches are turned OFF
      else{
          //Only D9 is ON
          P1OUT |= (D7 + D9);
          P1OUT &= ~(D5 + D6);
      }
      #endif

      #ifndef polling
      //Poll PB6
      int swTemp6 = P1IN;
      debounceButtons(PB6);

      swState6 &= PB6;
      swTemp6 = (P1IN >> 4) & 0x01;

      if(swTemp6 == 1)
              swState6 = 0;
          else
              swState6 = 1;

      __delay_cycles(50);
      // Both switches are turned ON
      if(swState5 == 1 && swState6 == 1){
        // D9,D7 is ON and the others are turned OFF
        P1OUT |= D9;
        P1OUT &= ~(D5 + D6 + D7); // D7 works with Active Low
      }


      // PB5 is ON and PB6 is OFF
      else if(swState5 == 1 && swState6 !=1){
          //D6 and D9 toggle at 250ms alternatively, D7 and D5 are OFF
          d6D9Toggle();
          P1OUT &= ~D5;
          P1OUT |= D7;
      }



      // PB6 is ON and PB5 is OFF
      else if(swState5 !=1 && swState6 == 1){
          // D5 and D9 are turned ON and the others are turned OFF
          P1OUT |= (D5 + D9 + D7);
          P1OUT &= ~(D6);
      }


      // Both switches are turned OFF
      else{
          //Only D9 is ON
          P1OUT |= (D7 + D9);
          P1OUT &= ~(D5 + D6);
      }
      # endif



  }
}


// ISR for monitoring PB5
# pragma vector = PORT1_VECTOR
__interrupt void Port_1 ( void ) {

    // P1IFG flag is set if the interrupt is generated
    // when PB5 is pressed i.e., BIT3 in P1IN changes from 1 -> 0
    if (P1IFG & PB5) {
        // high-to-low transition
        if (P1IES & PB5){
            // If bit3 is 0 then, high to low is detected
            debounceButtons(PB5);
            swState5 = 1;
        }

        else
            swState5 = 0;


        // toggle P1IES for next interrupt
        P1IES ^= PB5;

        // Clear interrupt flag
        P1IFG &= ~PB5;
    }
}
