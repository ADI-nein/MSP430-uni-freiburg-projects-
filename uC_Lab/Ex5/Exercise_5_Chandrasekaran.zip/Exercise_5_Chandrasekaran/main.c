//Exercise_5_Chandrasekaran

#include <msp430.h>
#include <templateEMP.h>

/**
 * main.c
 *
 * NTC range calculation assumptions:
 * Reading range is from 0-Vcc
 * which is approximately 0-3.3V
 *
 * 10 bit resolution ADC gives us:
 * 3.3/1024 = 3.222mV step size
 *
 * Range from schematic:
 * At room temp(25 deg) V = 1.1
 * So, ADC count = (1.1/3.222) * 10^3 = 341
 *
 * After activating the heater,
 * Assuming max temp is 55deg V = 2.2V
 * So, ADC count = (2.2/3.222) * 10^3 = 681
 *
 * A total of 340 possible values can be recorded.
 * Ranges can be defined by:
 * 341 - 409 ----> D1 glows
 * 410 - 477 ----> D2 glows
 * 478 - 546 ----> D3 glows
 * 547 - 613 ----> D4 glows
 * 614 - 681 ----> D6 glows (temperature is too high)
 */

// Macros
//#define task1_5sec //task1 definition
//#define task2bd_Thermometer
#define task2e_DynThermometer

#define GREENLED BIT0
#define REDLED BIT2
#define PB5 BIT3
#define RELAY_STAT BIT4
#define NTC BIT5

int swState5 = 0;
volatile int temprature, flag;

// Function Definitions
void fourHzBlink();
void watchdogInit();
void thermometer();
void dynamicThermometer();

int main(void)
{

    initMSP();

    // Setting PB5 as input pin
    P1DIR &= ~PB5;

    // Enable Pull up Resistor
    P1REN |= PB5;
    P1OUT |= PB5;


    // Setting LED as output pin
    P1DIR |= GREENLED;
    // Turn-OFF the LED initially
    P1OUT &= ~GREENLED;


    //setting PB5 and PB6 interrupts
    __enable_interrupt(); //Enable Global interrupts
    P1IES |= PB5;  // set to 1 for High to low transition
    P1IFG &= ~PB5 ; //Clear the interrupt
    P1IE |= PB5; //Enable interrupt for PB5 and PB6

    // Route VLOCLK to ACLK i.e., f= 12kHz, 16 bit timer
    /* Set Mode 2 for LFXT1 : VLO*
     LFXT1 mode select
     0b = Low-frequency mode
     1b = High-frequency mode - source family guide*/
    BCSCTL1 &= ~XTS;

    #ifdef task1_5sec
    BCSCTL1 |= DIVA_1; // f/2 = 6Khz

    /* t = (1/f)* 32,768
       t = (1/6*10^3)* 32,768.
       t is approximatley 5.5s */
    #endif

    #ifndef task1_5sec
        BCSCTL1 |= DIVA_3;
        /* t = (1/f)* 32,768
           t = (1/1.5*10^3)* 32,768.
           t is approximatley 21.9s */

        // Turn ADC on ; use 16 clocks as sample & hold time ( see p . 559 in the user guide )
        ADC10CTL0 = ADC10ON + ADC10SHT_2 ;


        // Enable P1 .5 as AD input - NTC connected to 1.5
        ADC10AE0 |= NTC ;

        // Select channel 5 as input for the following conversion ( s )
        ADC10CTL1 = INCH_5 ;

        // Set P3.4 and P3.2 as output
        P3DIR |= RELAY_STAT;
        //Turn off relay initially
        P3OUT &= ~RELAY_STAT;

        P3DIR |= REDLED;
        // Initially turn D6 off
        P3OUT &= ~REDLED;

        // Configuring SR2
        //P2.0 to P2.6 are all outputs
        P2DIR |= (BIT0 | BIT1 | BIT2 | BIT3 | BIT4 | BIT5 | BIT6) ;

        // Modify XTAL pins to be I / O
        P2SEL &= ~(BIT6 | BIT7) ;
        P2SEL2  &= ~(BIT6 | BIT7);

        // Reset clock signal to zero.
        P2OUT   &= ~BIT4;


        // Clear the shift registers with /CLR and reset it afterwards.
        P2OUT &= ~BIT5;
        P2OUT |= BIT5;

        // Set the shift register 2 mode right shift mode (S0 = 1 , S1 = 0) ,
        P2OUT |= BIT0 ;
        P2OUT &= ~BIT1 ;


        //Write 0 to all LEDs
        P2OUT &= ~BIT6 ;

        //Reset TA0
        TA0CTL |= TACLR;
        // ACLK is my source for Timer A
        TA0CTL |= TASSEL_1 + MC_1;
        // enable CCRO interrupt
        TACCTL0 |= CCIE;
        //clear interput flag
        TACCTL0 &= ~CCIFG;

        // Count up to 2 and generate interrupt
        TACCR0  = 2;

    #ifdef task2e_DynThermometer

        //
        P3DIR &= ~RELAY_STAT;

        P3DIR |= BIT5;
        P3SEL |= BIT5;

        // Turn relay OFF
        P3OUT &= ~BIT5;

        TACCR1 = 1;

    #endif



    #endif


    /* Mode 2 for LFXT1 : VLO  The LFXT1Sx bits should be programmed to 10b during
       the initialization and start-up code to select VLOCLK - source MSP family guide*/
    BCSCTL3 |= LFXT1S_2;

    // stop watchdog timer
    WDTCTL = WDTPW | WDTHOLD;

    // Initialising the WDT
    watchdogInit();


    while(1){

    #ifdef task2bd_Thermometer
        thermometer();
    #endif

        fourHzBlink();
        dynamicThermometer();

        watchdogInit();
    }



}


void watchdogInit(){
    WDTCTL = WDTPW + WDTCNTCL + WDTSSEL;
}

void fourHzBlink(){
    // If button is pressed then we want to go into an artificial deadlock

    while(swState5){
        P1OUT ^= GREENLED;
        __delay_cycles(125000);
    }


}


void thermometer(){


    if(temprature >= 613){
        __delay_cycles(100000);
        // Turn relay OFF once we reach the "overheating zone"
        P3OUT &= ~RELAY_STAT;
    }


    else if(temprature <= 478){
        __delay_cycles(100000);
        // turn the relay ON
        P3OUT |= RELAY_STAT;
    }



}

void dynamicThermometer(){

    if(temprature >= 613){
//        __delay_cycles(100000);
        // Turn relay OFF once we reach the "overheating zone"
        TA0CCTL1 = 0;

    }


    else if(temprature <= 478){
        TA0CCTL1 = OUTMOD_7 ; /* PWM output mode: 7 - PWM reset/set */

    }
}


// ISR for monitoring PB5
# pragma vector = PORT1_VECTOR
__interrupt void Port_1 ( void ) {

    // P1IFG flag is set if the interrupt is generated
    // when PB5 is pressed i.e., BIT3 in P1IN changes from 1 -> 0
    if(P1IFG & PB5){
        if(P1IES ^ PB5)
            swState5 = 1;
        P1IFG &= ~PB5;
    }


}

// ISR for monitoring Timer 0
# pragma vector = TIMER0_A0_VECTOR
__interrupt void Timer_A_CCR0 ( void ) {

    if(CCIFG)
        flag++;

    ADC10CTL0 |= ENC + ADC10SC ;

    // Wait until result is ready
    while (ADC10CTL1 & ADC10BUSY) ;

    // If result is ready , copy it to temprature
    temprature = ADC10MEM ;

    if(flag % 1000 == 0){
        // Clear the shift registers with /CLR and reset it afterwards.
        P2OUT &= ~BIT5;
        P2OUT |= BIT5;
    }



    // 341 - 409 ----> D1 glows
    if(temprature >= 341 && temprature <= 409 && flag % 1000 == 0){
        // Set SR to 1 to shift data in
        P2OUT |= BIT6;
        // apply a rising clock edge to shift data in
        P2OUT |= BIT4 ;
        // reset the clock
        P2OUT &= ~BIT4 ;

        // Turn D6 off
        P3OUT &= ~REDLED;

        // Print temprature to the serial console
        serialPrintInt(temprature);
        serialPrintln("\t");

    }

    // 410 - 477 ----> D2 glows
    else if(temprature >= 410 && temprature <= 477 && flag % 1000 == 0){
        // apply the data to be shifted at SR ( SR = 1 to insert a 1) .
        P2OUT |= BIT6 ;

        // apply a rising clock edge to shift data in
        P2OUT |= BIT4;
        // reset the clock
        P2OUT &= ~ BIT4;

        // set SR to 0 , because we don �t want D1 to be on
        P2OUT &= ~ BIT6 ;

        // apply a rising clock edge to shift data in
        P2OUT |= BIT4;
        // reset the clock
        P2OUT &= ~ BIT4 ;

        // Turn D6 off
        P3OUT &= ~REDLED;



        // Print temprature to the serial console
        serialPrintInt (temprature);
        serialPrintln("\t");
    }

    // 478 - 546 ----> D3 glows
    else if(temprature >= 478 && temprature <= 546 && flag % 1000 == 0){
        // apply the data to be shifted at SR ( SR = 1 to insert a 1) .
        P2OUT |= BIT6 ;

        // apply a rising clock edge to shift data in
        P2OUT |= BIT4;
        // reset the clock
        P2OUT &= ~ BIT4 ;

        // set SR to 0 , because we don �t want D1 to be on
        P2OUT &= ~ BIT6 ;
        // apply a rising clock edge to shift data in
        P2OUT |= BIT4;
        // reset the clock
        P2OUT &= ~BIT4 ;

        // set SR to 0 , because we don �t want D2 to be on
        P2OUT &= ~ BIT6 ;
        // apply a rising clock edge to shift data in
        P2OUT |= BIT4;
        // reset the clock
        P2OUT &= ~BIT4 ;


        // Turn D6 off
        P3OUT &= ~REDLED;

        // Print temprature to the serial console
        serialPrintInt (temprature);
        serialPrintln("\t");

    }


    // 547 - 613 ----> D4 glows
    else if(temprature >=547 && temprature <= 613 && flag % 1000 == 0){

        // apply the data to be shifted at SR ( SR = 1 to insert a 1) .
        P2OUT |= BIT6 ;

        // apply a rising clock edge to shift data in
        P2OUT |= BIT4;
        // reset the clock
        P2OUT &= ~ BIT4 ;

        // set SR to 0 , because we don �t want D1 to be on
        P2OUT &= ~ BIT6 ;
        // apply a rising clock edge to shift data in
        P2OUT |= BIT4;
        // reset the clock
        P2OUT &= ~ BIT4 ;

        // set SR to 0 , because we don �t want D2 to be on
        P2OUT &= ~ BIT6 ;
        // apply a rising clock edge to shift data in
        P2OUT |= BIT4;
        // reset the clock
        P2OUT &= ~ BIT4 ;

        // set SR to 0 , because we don �t want D3 to be on
        P2OUT &= ~ BIT6 ;
        // apply a rising clock edge to shift data in
        P2OUT |= BIT4;
        // reset the clock
        P2OUT &= ~ BIT4 ;

        // Turn D6 off
        P3OUT &= ~REDLED;

        // Print temprature to the serial console
        serialPrintInt (temprature);
        serialPrintln("\t");

    }

    // 614 - 681 ----> D6 glows (temperature is too high)
    else if(temprature >= 614 && temprature < 681 && flag % 1000 == 0){

        P3OUT |= REDLED;

        // Print temprature to the serial console
        serialPrintInt (temprature);
        serialPrintln("\t");
    }


    TACCTL0 &= ~CCIFG;
}



