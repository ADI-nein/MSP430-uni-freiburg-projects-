//Exercise_4_Chandrasekaran
/*
 * CON4:
 * Middle to Buzzer(X1)
 * Left to PWM (3.6) - output
 * Right to DAC_IN (X2) - input
 *
 * CON3:
 * PIN6 configured as PWM
 * PIN3 configured as interrupt pin
 *
 * CON2:
 * PIN4 configured as GPIO to control the Relay
 *
 * JP5 set to VFO
 *
 */
#include <msp430.h>
#include <templateEMP.h>

#define INTERRUPT_PIN BIT3
#define RELAY_STAT BIT4

// Function declarations
void playMelody1();  // Function to play melody 1
void playMelody2();  // Function to play melody 2
void playMelody();   // Function to play melody based on the interrupt

// Melodies to be played
int melody1[7] = {2000, 3000, 4000, 5000, 6000, 7000, 8000};
int melody2[7] = {800, 700 , 850 , 750, 800, 700, 850};


int interruptFlag = 0;

int main(void)
{
    initMSP();

    WDTCTL = WDTPW | WDTHOLD;   // stop watchdog timer

    P3DIR |= BIT6 ; // P3.6 output
    P3SEL |= BIT6 ; // P3.6 TA0 .2 option

    TA0CCTL2 = OUTMOD_3 ; // CCR2 set / reset
    TA0CCR0 = 1000; // PWM Period : 1000 us
    TA0CCR2 = 500; // CCR2 PWM duty cycle (50 %)
    TA0CTL = TASSEL_2 + MC_1 ; // SMCLK ; MC_1 -> up mode ;
    // MC_2 -> cont mode ,
    // MC_3 -> up - down - mode
    // In continous mode , internal reference
    // counts up to 0 xFFFF before starting at
    // 0 x0000 again . In any other mode it counts
    // up until it hits TACCR0
    // ( p . 364 in the family guide )

    // Pin 2.4 controls the relay
    P2DIR |= RELAY_STAT;
    // Keeping relay connected to the NC terminal
    P2OUT &= ~RELAY_STAT;

    // Pin 1.3 is the interrupt pin connected to COMP_OUT
    P1DIR &= ~INTERRUPT_PIN;

    P1IE |= INTERRUPT_PIN; // Enable interrupt for PIN 1.3
    __enable_interrupt() ; // Enable Global interrupts
    P1IES &= ~INTERRUPT_PIN ;  // set to 0 for Low to High transition (Select Edge Register)
    P1IFG &= ~INTERRUPT_PIN ; // Clear the interrupt



    while(1){
        // Function call that plays melody based on the interrupt generated
        playMelody();
    }
}

// Function definition to play Melody 1
void playMelody1(){
    unsigned int counter;

    for (counter = 0; counter < 7; counter ++) {
        TA0CCR0 =  melody1[counter] ;
        __delay_cycles(200000);

    }

    if(counter == 7)
        TA0CCR0 =  0;
}

// Function definition to play Melody 2
void playMelody2(){
    unsigned int counter;

    for (counter = 0; counter < 7; counter ++) {
        TA0CCR0 =  melody2[counter] ;
        __delay_cycles(200000);

    }

    if(counter == 7)
        TA0CCR0 =  0;

}


void playMelody(){
    if(interruptFlag > 0){

        // Wait for one second
        __delay_cycles(1000000);


        // Knocked once
        if(interruptFlag == 1){

            P2OUT |= RELAY_STAT;  // Here, switch relay to NO terminal
            playMelody1();  // Generate the PWM sequence to play melody 1

            __delay_cycles(10000);
            P2OUT &= ~RELAY_STAT;     // Set relay to NC terminal again to allow reading of knocks

        }

        // Knocked twice
        else if(interruptFlag == 2){

            P2OUT |= RELAY_STAT;  // Here, switch relay to NO terminal
            playMelody2(); // Generate the PWM sequence to play melody 2


            __delay_cycles(10000);
            P2OUT &= ~RELAY_STAT;     // Set relay to NC terminal again to allow reading of knocks
        }

    }


    interruptFlag = 0; // Reset interrupt Flag

}


# pragma vector = PORT1_VECTOR
__interrupt void Port_1 ( void ) {

    // P1IFG flag is set if the interrupt is generated
    // When an output is generated at COMP_OUT
    // BIT3 in P1IN changes from 0 -> 1
    if (P1IFG & INTERRUPT_PIN) {
            interruptFlag++;

        __delay_cycles(250000);


        // Clear interrupt flag
        P1IFG &= ~INTERRUPT_PIN;
    }
}
