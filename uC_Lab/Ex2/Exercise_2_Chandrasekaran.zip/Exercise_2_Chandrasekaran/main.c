//Exercise_2_Chandrasekaran

#include <msp430.h>
#include <templateEMP.h>

//Defining Macros for Shift register 1
#define SREG1_S0 BIT2
#define SREG1_S1 BIT3

//Defining Macros for Shift register 2
#define SREG2_S0 BIT0
#define SREG2_S1 BIT1

//Clock pin
#define CK BIT4

//Master Clear PIN
#define CLR BIT5

//Shift Right
#define SR BIT6

//Output of SREG1
#define QD BIT7



// Function declaration to monitor LED position, know the current status of the button
int modeControl(int ledPosition, int button);
int currentButtonState();

//Variables to track LED position and which button is pressed
int ledPos = 0;
int button = 0;
int defaultState = 0;


int main(void) {
    // Initialise controller
    initMSP();

    //P2.7 is input
    P2DIR &= ~QD;

    // Stop watchdog timer
    WDTCTL = WDTPW | WDTHOLD ;

    //P2.0 to P2.6 are all outputs
    P2DIR |= (BIT0 | BIT1 | BIT2 | BIT3 | BIT4 | BIT5 | BIT6) ;

    // Modify XTAL pins to be I / O
    P2SEL &= ~(BIT6 | BIT7) ;
    P2SEL2  &= ~(BIT6 | BIT7);

    // Reset clock signal to zero.
    P2OUT   &= ~BIT4;

    // Clear the shift registers with /CLR and reset it afterwards.
    P2OUT &= ~CLR;
    P2OUT |= CLR;

    // Set the shift register 2 mode right shift mode (S0 = 1 , S1 = 0) ,
    P2OUT |= SREG2_S0 ;
    P2OUT &= ~ SREG2_S1 ;

    ledPos = 0, button = 0;

    while(1){
        ledPos = modeControl(ledPos, button);
    }
}


int currentButtonState(){
    int i;
    int buttonState;


    // SR1 to parallel (S0 = S1 = 1)
    P2OUT |= (SREG1_S0 + SREG1_S1);

    // SR2 to maintain previous states (S0 = S1 = 0)
    // as we don't want the clock to affect it
    P2OUT &= ~(SREG2_S0 + SREG2_S1);

    // Applying a right shift to detect next button Change
    // Next time when the function is called QD is 0
    P2OUT |= CK ;
    // reset the clock
    P2OUT &= ~ CK ;


    for(i = 4; i > 0; --i){

        if(P2IN & QD){
            buttonState = i;
            break;
        }

        // Set to right shift mode
        P2OUT   &= ~SREG1_S1;

        // Applying clock would shift 1 to the right
        // As SR is pulled high
        P2OUT |= CK ;
        // reset the clock
        P2OUT &= ~ CK ;

        P2OUT |= SREG1_S1;
    }

    // Set the shift register 2 mode right shift mode (S0 = 1 , S1 = 0) ,
    P2OUT |= SREG2_S0 ;
    P2OUT &= ~ SREG2_S1 ;

    if((buttonState == 3 || defaultState == 3) && buttonState !=2)
        defaultState = 3;

    else if(buttonState == 2 || defaultState == 2)
        defaultState = 2;

    return buttonState;
}

int modeControl(int ledPosition, int button){
    int i = 0;
    button = currentButtonState();

    // Check if a default state has been set
    if(defaultState == 0)
        button = 0;

    // Initial mode when no state is defined turning all LEDs off
    if(button == 0 && defaultState == 0){

        P2OUT &= ~CLR ;
        P2OUT |= CLR;

        // Set the shift register 2 mode right shift mode ( S0 = 1 , S1 = 0) ,
        P2OUT |= SREG2_S0 ;
        P2OUT &= ~ SREG2_S1 ;

        //Write 0 to all LEDs
        P2OUT &= ~BIT6 ;

        for(i=ledPos ; i < 4 ; i++){
            // apply a rising clock edge to shift data in
            P2OUT |= CK ;
            // reset the clock
            P2OUT &= ~ CK ;

            // set SR to 0 , applying 0 to all LEDs
            P2OUT &= ~ SR ;

        }


    }

    // Mode 1 - Reverse Sped up mode
    if(button == 1 && defaultState != 0){
        // Clear the shift registers with /CLR and reset it afterwards.
        P2OUT   &= ~CLR;
        P2OUT   |= CLR;

        for(i = ledPosition; i >= 0; i--){
            if(i == 4){
                // Clear the shift registers with /CLR and reset it afterwards.
                P2OUT   &= ~CLR;
                P2OUT   |= CLR;

                // apply the data to be shifted at SR ( SR = 1 to insert a 1) .
                P2OUT |= BIT6 ;

                // apply a rising clock edge to shift data in
                P2OUT |= CK;
                // reset the clock
                P2OUT &= ~ CK ;

                // set SR to 0 , because we don �t want D1 to be on
                P2OUT &= ~ BIT6 ;
                // apply a rising clock edge to shift data in
                P2OUT |= CK;
                // reset the clock
                P2OUT &= ~ CK ;

                // set SR to 0 , because we don �t want D2 to be on
                P2OUT &= ~ BIT6 ;
                // apply a rising clock edge to shift data in
                P2OUT |= CK;
                // reset the clock
                P2OUT &= ~ CK ;

                // set SR to 0 , because we don �t want D3 to be on
                P2OUT &= ~ BIT6 ;
                // apply a rising clock edge to shift data in
                P2OUT |= CK;
                __delay_cycles(125000);
                // reset the clock
                P2OUT &= ~ CK ;

                ledPosition = 4;
            }

            else if(i == 3){
                // Clear the shift registers with /CLR and reset it afterwards.
                P2OUT   &= ~CLR;
                P2OUT   |= CLR;

                // apply the data to be shifted at SR ( SR = 1 to insert a 1) .
                P2OUT |= BIT6 ;

                // apply a rising clock edge to shift data in
                P2OUT |= CK;
                // reset the clock
                P2OUT &= ~ CK ;

                // set SR to 0 , because we don �t want D1 to be on
                P2OUT &= ~ BIT6 ;
                // apply a rising clock edge to shift data in
                P2OUT |= CK;
                // reset the clock
                P2OUT &= ~ CK ;

                // set SR to 0 , because we don �t want D2 to be on
                P2OUT &= ~ BIT6 ;
                // apply a rising clock edge to shift data in
                P2OUT |= CK;
                __delay_cycles(125000);
                // reset the clock
                P2OUT &= ~ CK ;

                ledPosition = 3;

            }

            else if (i == 2){
                // Clear the shift registers with /CLR and reset it afterwards.
                P2OUT   &= ~CLR;
                P2OUT   |= CLR;

                // apply the data to be shifted at SR ( SR = 1 to insert a 1) .
                P2OUT |= BIT6 ;

                // apply a rising clock edge to shift data in
                P2OUT |= CK;
                // reset the clock
                P2OUT &= ~ BIT4;

                // set SR to 0 , because we don �t want D1 to be on
                P2OUT &= ~ BIT6 ;
                // apply a rising clock edge to shift data in
                P2OUT |= CK;
                __delay_cycles(125000);
                // reset the clock
                P2OUT &= ~ CK ;

                ledPosition = 2;

            }

            else if (i == 1){
                // Clear the shift registers with /CLR and reset it afterwards.
                P2OUT &= ~CLR;
                P2OUT |= CLR;

                // apply the data to be shifted at SR ( SR = 1 to insert a 1) .
                P2OUT |= SR;

                // apply a rising clock edge to shift data in
                P2OUT |= CK;
                __delay_cycles(125000);
                // reset the clock
                P2OUT &= ~ CK ;

                ledPosition = 1;
            }

            else if(i == 0)
                ledPosition = 4;

            button = currentButtonState();

            //Check of button 1 is released
            if(button != 1){
                // Clear the shift registers with /CLR and reset it afterwards.
                P2OUT &= ~CLR;
                P2OUT |= CLR;
                break;
            }

        }

    }

    // Mode 2 - to pause at current led state
    else if((button == 2 || defaultState == 2) && button != 3 && button != 4){
        // Clear the shift registers with /CLR and reset it afterwards.
        P2OUT   &= ~CLR;
        P2OUT   |= CLR;

        if(ledPosition == 4){
             // apply the data to be shifted at SR ( SR = 1 to insert a 1) .
             P2OUT |= BIT6 ;

             // apply a rising clock edge to shift data in
             P2OUT |= CK;
             // reset the clock
             P2OUT &= ~ CK ;

             // set SR to 0 , because we don �t want D1 to be on
             P2OUT &= ~ BIT6 ;
             // apply a rising clock edge to shift data in
             P2OUT |= CK;
             // reset the clock
             P2OUT &= ~ CK ;

             // set SR to 0 , because we don �t want D2 to be on
             P2OUT &= ~ BIT6 ;
             // apply a rising clock edge to shift data in
             P2OUT |= CK;
             // reset the clock
             P2OUT &= ~ CK ;

             // set SR to 0 , because we don �t want D3 to be on
             P2OUT &= ~ BIT6 ;
             // apply a rising clock edge to shift data in
             P2OUT |= CK;
             __delay_cycles(125000);
             // reset the clock
             P2OUT &= ~ CK ;

             ledPosition = 4;
         }

         else if(ledPosition == 3){
             // apply the data to be shifted at SR ( SR = 1 to insert a 1) .
             P2OUT |= BIT6 ;

             // apply a rising clock edge to shift data in
             P2OUT |= CK;
             // reset the clock
             P2OUT &= ~ CK ;

             // set SR to 0 , because we don �t want D1 to be on
             P2OUT &= ~ BIT6 ;
             // apply a rising clock edge to shift data in
             P2OUT |= CK;
             // reset the clock
             P2OUT &= ~ CK ;

             // set SR to 0 , because we don �t want D2 to be on
             P2OUT &= ~ BIT6 ;
             // apply a rising clock edge to shift data in
             P2OUT |= CK;
             __delay_cycles(125000);
             // reset the clock
             P2OUT &= ~ CK ;

             ledPosition = 3;

         }

         else if (ledPosition == 2){
             // apply the data to be shifted at SR ( SR = 1 to insert a 1) .
             P2OUT |= BIT6 ;

             // apply a rising clock edge to shift data in
             P2OUT |= CK;
             // reset the clock
             P2OUT &= ~ BIT4;

             // set SR to 0 , because we don �t want D1 to be on
             P2OUT &= ~ BIT6 ;
             // apply a rising clock edge to shift data in
             P2OUT |= CK;
             __delay_cycles(125000);
             // reset the clock
             P2OUT &= ~ CK ;

             ledPosition = 2;

         }

         else if (ledPosition == 1){
             // apply the data to be shifted at SR ( SR = 1 to insert a 1) .
             P2OUT |= SR;

             // apply a rising clock edge to shift data in
             P2OUT |= CK;
             __delay_cycles(125000);
             // reset the clock
             P2OUT &= ~ CK ;

             ledPosition = 1;
         }

    }

    // Mode 3 Normal Running light
    else if((button == 3 || defaultState == 3) && button != 4){
        // Clear the shift registers with /CLR and reset it afterwards.
        P2OUT   &= ~CLR;
        P2OUT   |= CLR;

        if(ledPos == 0)
            ledPosition = 1;

        // Set SR to 1 to shift data in
        P2OUT |= SR;
        int temp = ledPosition;

        if(temp == 2){
            // apply a rising clock edge to shift data in
            P2OUT |= CK ;
            // reset the clock
            P2OUT &= ~CK ;

            // set SR to 0 to turn OFF LED1
            P2OUT &= ~ SR ;

            ledPosition = 2;
        }

        else if (temp == 3){
            // apply a rising clock edge to shift data in
            P2OUT |= CK ;
            // reset the clock
            P2OUT &= ~CK ;

            // set SR to 0 to turn OFF other LED1
            P2OUT &= ~ SR ;

            // apply a rising clock edge to shift data in
            P2OUT |= CK ;
            // reset the clock
            P2OUT &= ~CK ;

            // set SR to 0 to turn OFF other LED2
            P2OUT &= ~ SR ;

            ledPosition = 3;

        }

        else if(temp == 4){
            // apply a rising clock edge to shift data in
            P2OUT |= CK ;
            // reset the clock
            P2OUT &= ~CK ;

            // set SR to 0 to turn OFF other LED1
            P2OUT &= ~ SR ;

            // apply a rising clock edge to shift data in
            P2OUT |= CK ;
            // reset the clock
            P2OUT &= ~CK ;

            // set SR to 0 to turn OFF other LED2
            P2OUT &= ~ SR ;

            // apply a rising clock edge to shift data in
            P2OUT |= CK ;
            // reset the clock
            P2OUT &= ~CK ;

            // set SR to 0 to turn OFF other LED3
            P2OUT &= ~ SR ;

            ledPosition = 4;

        }

        for(i = ledPosition; i <= 4; i++){

            button = currentButtonState();

            // Check if any other button is pressed
            if(button == 4 || button == 2 || button == 1){
                // Clear the shift registers with /CLR and reset it afterwards.
                P2OUT &= ~CLR;
                P2OUT |= CLR;
                break;
            }

           // apply a rising clock edge to shift data in
            P2OUT |= CK ;
            __delay_cycles(250000);
            // reset the clock
            P2OUT &= ~CK ;

            // set SR to 0 to turn OFF other LEDs
            P2OUT &= ~ SR ;
            ledPosition = i;
        }
        // If out of the for loop  reset Led position
        if(i == 5)
            ledPosition = 1;

    }


    // Mode 4 i.e., sped up mode 3
    else if(button == 4 && defaultState != 0){
        // Clear the shift registers with /CLR and reset it afterwards.
        P2OUT   &= ~CLR;
        P2OUT   |= CLR;

        // Set SR to 1 to shift data in
        P2OUT |= SR;
        int temp4 = ledPosition;

        if(temp4 == 2){
            // apply a rising clock edge to shift data in
            P2OUT |= CK ;
            // reset the clock
            P2OUT &= ~CK ;

            // set SR to 0 to turn OFF LED1
            P2OUT &= ~ SR ;
            ledPosition = 2;
        }

        else if (temp4 == 3){
            // apply a rising clock edge to shift data in
            P2OUT |= CK ;
            // reset the clock
            P2OUT &= ~CK ;

            // set SR to 0 to turn OFF other LED1
            P2OUT &= ~ SR ;

            // apply a rising clock edge to shift data in
            P2OUT |= CK ;
            // reset the clock
            P2OUT &= ~CK ;

            // set SR to 0 to turn OFF other LED2
            P2OUT &= ~ SR ;

            ledPosition = 3;
        }

        else if(temp4 == 4){
            // apply a rising clock edge to shift data in
            P2OUT |= CK ;
            // reset the clock
            P2OUT &= ~CK ;

            // set SR to 0 to turn OFF other LED1
            P2OUT &= ~ SR ;

            // apply a rising clock edge to shift data in
            P2OUT |= CK ;
            // reset the clock
            P2OUT &= ~CK ;

            // set SR to 0 to turn OFF other LED2
            P2OUT &= ~ SR ;

            // apply a rising clock edge to shift data in
            P2OUT |= CK ;
            // reset the clock
            P2OUT &= ~CK ;

            // set SR to 0 to turn OFF other LED3
            P2OUT &= ~ SR ;

            ledPosition = 4;

        }

        for(i = ledPosition; i <= 4; i++){

            ledPosition = i;
            button = currentButtonState();

            // Check if button 4 is released
            if(button != 4){
               // Clear the shift registers with /CLR and reset it afterwards.
               P2OUT &= ~CLR;
               P2OUT |= CLR;
               break;
            }


            // apply a rising clock edge to shift data in
            P2OUT |= CK ;
            __delay_cycles(125000);
            // reset the clock
            P2OUT &= ~CK ;

            // set SR to 0 to turn OFF other LEDs
            P2OUT &= ~ SR ;
        }

        // If out of the for loop  reset Led position
        if(i == 5)
            ledPosition = 1;
    }

    // Return the specified position
    return ledPosition;
}
